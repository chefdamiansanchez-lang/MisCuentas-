@file:OptIn(ExperimentalMaterial3Api::class)

package com.miscuentas.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

val Crema = Color(0xFFFFF8EE)
val Naranja = Color(0xFFE8833A)
val Verde = Color(0xFF4C9A5F)
val Rojo = Color(0xFFC8553D)
val Durazno = Color(0xFFFFEBD6)
val TextoOscuro = Color(0xFF3B2F2F)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Naranja,
            secondary = Verde,
            background = Crema,
            surface = Crema,
            onBackground = TextoOscuro,
            onSurface = TextoOscuro,
            secondaryContainer = Durazno
        ),
        content = content
    )
}

fun dinero(v: Double): String = String.format(Locale.getDefault(), "\$ %,.2f", v)

fun formatoDia(dia: Long): String =
    DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()).format(LocalDate.ofEpochDay(dia))

@Composable
fun App(repo: Repo) {
    val movs = remember { mutableStateListOf<Movimiento>().also { it.addAll(repo.cargarMovimientos()) } }
    val cats = remember { mutableStateListOf<Categoria>().also { it.addAll(repo.cargarCategorias()) } }
    var tab by remember { mutableIntStateOf(0) }
    var dialogo by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf<Movimiento?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                listOf("🏠" to "Inicio", "📊" to "Informes", "🏷️" to "Categorías")
                    .forEachIndexed { i, par ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(par.first, fontSize = 20.sp) },
                            label = { Text(par.second) }
                        )
                    }
            }
        },
        floatingActionButton = {
            if (tab != 2) {
                FloatingActionButton(
                    onClick = { editando = null; dialogo = true },
                    containerColor = Naranja,
                    contentColor = Color.White
                ) { Text("+", fontSize = 28.sp) }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Inicio(movs) { m -> editando = m; dialogo = true }
                1 -> Informes(movs) { m -> editando = m; dialogo = true }
                else -> Categorias(
                    cats = cats,
                    onAdd = { c ->
                        cats.add(c)
                        repo.guardarCategorias(cats.toList())
                    },
                    onDelete = { c ->
                        cats.remove(c)
                        repo.guardarCategorias(cats.toList())
                    }
                )
            }
        }
    }

    if (dialogo) {
        val actual = editando
        MovimientoDialog(
            inicial = actual,
            cats = cats,
            onGuardar = { nuevo ->
                val idx = movs.indexOfFirst { it.id == nuevo.id }
                if (idx >= 0) movs[idx] = nuevo else movs.add(nuevo)
                repo.guardarMovimientos(movs.toList())
                dialogo = false
            },
            onEliminar = if (actual == null) null else {
                {
                    movs.removeAll { it.id == actual.id }
                    repo.guardarMovimientos(movs.toList())
                    dialogo = false
                }
            },
            onCerrar = { dialogo = false }
        )
    }
}

@Composable
fun Inicio(movs: List<Movimiento>, onTap: (Movimiento) -> Unit) {
    val hoy = LocalDate.now().toEpochDay()
    val mesActual = YearMonth.now()
    val delMes = movs.filter { YearMonth.from(LocalDate.ofEpochDay(it.dia)) == mesActual }
    val deHoy = movs.filter { it.dia == hoy }.sortedByDescending { it.id }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Mis Cuentas",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Naranja
            )
        }
        item { ResumenCard("Hoy", deHoy) }
        item { ResumenCard("Este mes", delMes) }
        item {
            Text(
                "Movimientos de hoy",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        if (deHoy.isEmpty()) {
            item { Text("Todavía no registraste nada hoy. Tocá + para agregar.") }
        }
        items(deHoy, key = { it.id }) { m ->
            FilaMovimiento(m, mostrarFecha = false) { onTap(m) }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun Dato(titulo: String, valor: Double, color: Color) {
    Column {
        Text(titulo, style = MaterialTheme.typography.bodySmall)
        Text(dinero(valor), color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ResumenCard(titulo: String, lista: List<Movimiento>) {
    val ing = lista.filter { it.tipo == Tipo.INGRESO }.sumOf { it.monto }
    val gas = lista.filter { it.tipo == Tipo.GASTO }.sumOf { it.monto }
    val bal = ing - gas
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Durazno)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Dato("Ingresos", ing, Verde)
                Dato("Gastos", gas, Rojo)
                Dato("Balance", bal, if (bal >= 0) Verde else Rojo)
            }
        }
    }
}

@Composable
fun FilaMovimiento(m: Movimiento, mostrarFecha: Boolean, onClick: () -> Unit) {
    val color = if (m.tipo == Tipo.GASTO) Rojo else Verde
    val signo = if (m.tipo == Tipo.GASTO) "-" else "+"
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.categoria, fontWeight = FontWeight.Bold)
                val sub = listOfNotNull(
                    if (mostrarFecha) formatoDia(m.dia) else null,
                    m.nota.ifBlank { null }
                ).joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall)
            }
            Text("$signo ${dinero(m.monto)}", color = color, fontWeight = FontWeight.Bold)
        }
    }
}

enum class Periodo(val etiqueta: String) { DIA("Día"), SEMANA("Semana"), MES("Mes") }

@Composable
fun Informes(movs: List<Movimiento>, onTap: (Movimiento) -> Unit) {
    var periodo by remember { mutableStateOf(Periodo.DIA) }
    var ancla by remember { mutableStateOf(LocalDate.now()) }

    val desde: LocalDate
    val hasta: LocalDate
    when (periodo) {
        Periodo.DIA -> { desde = ancla; hasta = ancla }
        Periodo.SEMANA -> {
            desde = ancla.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            hasta = desde.plusDays(6)
        }
        Periodo.MES -> {
            desde = ancla.withDayOfMonth(1)
            hasta = ancla.withDayOfMonth(ancla.lengthOfMonth())
        }
    }

    val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
    val etiqueta = when (periodo) {
        Periodo.DIA -> fmt.format(desde)
        Periodo.SEMANA -> "${fmt.format(desde)} – ${fmt.format(hasta)}"
        Periodo.MES -> DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault())
            .format(ancla).replaceFirstChar { it.uppercase() }
    }

    fun mover(delta: Long) {
        ancla = when (periodo) {
            Periodo.DIA -> ancla.plusDays(delta)
            Periodo.SEMANA -> ancla.plusWeeks(delta)
            Periodo.MES -> ancla.plusMonths(delta)
        }
    }

    val lista = movs
        .filter { it.dia in desde.toEpochDay()..hasta.toEpochDay() }
        .sortedWith(compareByDescending<Movimiento> { it.dia }.thenByDescending { it.id })
    val porDia = lista.groupBy { it.dia }.toList().sortedByDescending { it.first }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Informes",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Naranja
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Periodo.values().forEach { p ->
                    FilterChip(
                        selected = periodo == p,
                        onClick = { periodo = p },
                        label = { Text(p.etiqueta) }
                    )
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = { mover(-1) }) { Text("◀") }
                Text(etiqueta, fontWeight = FontWeight.Bold)
                TextButton(onClick = { mover(1) }) { Text("▶") }
            }
        }
        item { ResumenCard(periodo.etiqueta, lista) }
        item { Desglose("Gastos por categoría", lista.filter { it.tipo == Tipo.GASTO }, Rojo) }
        item { Desglose("Ingresos por categoría", lista.filter { it.tipo == Tipo.INGRESO }, Verde) }

        if (periodo != Periodo.DIA && porDia.isNotEmpty()) {
            item {
                Text(
                    "Resumen por día",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            items(porDia, key = { it.first }) { par ->
                val ing = par.second.filter { it.tipo == Tipo.INGRESO }.sumOf { it.monto }
                val gas = par.second.filter { it.tipo == Tipo.GASTO }.sumOf { it.monto }
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        Modifier.padding(14.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatoDia(par.first), fontWeight = FontWeight.Bold)
                        Text("+ ${dinero(ing)}", color = Verde)
                        Text("- ${dinero(gas)}", color = Rojo)
                    }
                }
            }
        }

        item {
            Text(
                "Movimientos",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        if (lista.isEmpty()) {
            item { Text("No hay movimientos en este período.") }
        }
        items(lista, key = { it.id }) { m ->
            FilaMovimiento(m, mostrarFecha = true) { onTap(m) }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun Desglose(titulo: String, lista: List<Movimiento>, color: Color) {
    if (lista.isEmpty()) return
    val total = lista.sumOf { it.monto }
    val grupos = lista.groupBy { it.categoria }
        .map { it.key to it.value.sumOf { m -> m.monto } }
        .sortedByDescending { it.second }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            grupos.forEach { g ->
                Column {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(g.first)
                        Text(dinero(g.second), fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { (g.second / total).toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = color,
                        trackColor = Durazno
                    )
                }
            }
        }
    }
}

@Composable
fun Categorias(cats: List<Categoria>, onAdd: (Categoria) -> Unit, onDelete: (Categoria) -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var tipo by remember { mutableStateOf(Tipo.GASTO) }
    val limpio = nombre.trim()
    val repetida = cats.any { it.tipo == tipo && it.nombre.equals(limpio, ignoreCase = true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Categorías",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Naranja
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Durazno)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nueva categoría", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = tipo == Tipo.GASTO,
                            onClick = { tipo = Tipo.GASTO },
                            label = { Text("Gasto") }
                        )
                        FilterChip(
                            selected = tipo == Tipo.INGRESO,
                            onClick = { tipo = Tipo.INGRESO },
                            label = { Text("Ingreso") }
                        )
                    }
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            onAdd(Categoria(limpio, tipo))
                            nombre = ""
                        },
                        enabled = limpio.isNotEmpty() && !repetida
                    ) { Text("Agregar") }
                }
            }
        }
        item {
            Text("Gastos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(cats.filter { it.tipo == Tipo.GASTO }, key = { "G" + it.nombre }) { c ->
            FilaCategoria(c) { onDelete(c) }
        }
        item {
            Text("Ingresos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(cats.filter { it.tipo == Tipo.INGRESO }, key = { "I" + it.nombre }) { c ->
            FilaCategoria(c) { onDelete(c) }
        }
    }
}

@Composable
fun FilaCategoria(c: Categoria, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            Modifier.padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(c.nombre)
            TextButton(onClick = onDelete) { Text("Quitar", color = Rojo) }
        }
    }
}

@Composable
fun MovimientoDialog(
    inicial: Movimiento?,
    cats: List<Categoria>,
    onGuardar: (Movimiento) -> Unit,
    onEliminar: (() -> Unit)?,
    onCerrar: () -> Unit
) {
    var tipo by remember { mutableStateOf(inicial?.tipo ?: Tipo.GASTO) }
    var montoTxt by remember {
        mutableStateOf(
            inicial?.monto?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""
        )
    }
    var catSel by remember { mutableStateOf(inicial?.categoria ?: "") }
    var nota by remember { mutableStateOf(inicial?.nota ?: "") }
    var dia by remember { mutableStateOf(inicial?.dia ?: LocalDate.now().toEpochDay()) }
    var mostrarFecha by remember { mutableStateOf(false) }

    val opciones = buildList {
        addAll(cats.filter { it.tipo == tipo }.map { it.nombre })
        if (inicial != null && inicial.tipo == tipo && inicial.categoria !in this) add(inicial.categoria)
    }
    val categoria = if (catSel in opciones) catSel else (opciones.firstOrNull() ?: "")
    val monto = montoTxt.replace(',', '.').toDoubleOrNull()
    val valido = monto != null && monto > 0 && categoria.isNotBlank()

    AlertDialog(
        onDismissRequest = onCerrar,
        title = { Text(if (inicial == null) "Nuevo movimiento" else "Editar movimiento") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = tipo == Tipo.GASTO,
                        onClick = { tipo = Tipo.GASTO },
                        label = { Text("Gasto") }
                    )
                    FilterChip(
                        selected = tipo == Tipo.INGRESO,
                        onClick = { tipo = Tipo.INGRESO },
                        label = { Text("Ingreso") }
                    )
                }
                OutlinedTextField(
                    value = montoTxt,
                    onValueChange = { montoTxt = it },
                    label = { Text("Monto") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                if (opciones.isEmpty()) {
                    Text("Primero creá una categoría en la pestaña Categorías.", color = Rojo)
                } else {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        opciones.forEach { n ->
                            FilterChip(
                                selected = n == categoria,
                                onClick = { catSel = n },
                                label = { Text(n) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = nota,
                    onValueChange = { nota = it },
                    label = { Text("Nota (opcional)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { mostrarFecha = true }) {
                    Text("Fecha: ${formatoDia(dia)}")
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valido,
                onClick = {
                    onGuardar(
                        Movimiento(
                            id = inicial?.id ?: System.currentTimeMillis(),
                            tipo = tipo,
                            monto = monto ?: 0.0,
                            categoria = categoria,
                            nota = nota.trim(),
                            dia = dia
                        )
                    )
                }
            ) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (onEliminar != null) {
                    TextButton(onClick = onEliminar) { Text("Eliminar", color = Rojo) }
                }
                TextButton(onClick = onCerrar) { Text("Cancelar") }
            }
        }
    )

    if (mostrarFecha) {
        val st = rememberDatePickerState(initialSelectedDateMillis = dia * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { mostrarFecha = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { dia = Math.floorDiv(it, 86_400_000L) }
                    mostrarFecha = false
                }) { Text("Aceptar") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarFecha = false }) { Text("Cancelar") }
            }
        ) { DatePicker(state = st) }
    }
}
