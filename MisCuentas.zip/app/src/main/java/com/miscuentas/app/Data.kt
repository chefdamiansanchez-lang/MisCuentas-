package com.miscuentas.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class Tipo { GASTO, INGRESO }

data class Categoria(val nombre: String, val tipo: Tipo)

data class Movimiento(
    val id: Long,
    val tipo: Tipo,
    val monto: Double,
    val categoria: String,
    val nota: String,
    val dia: Long // dias desde 1970-01-01 (epoch day)
)

/** Guarda todo en el almacenamiento privado de la app, en el movil. */
class Repo(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("miscuentas", Context.MODE_PRIVATE)

    fun cargarMovimientos(): List<Movimiento> = try {
        val arr = JSONArray(prefs.getString("movs", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Movimiento(
                id = o.getLong("id"),
                tipo = Tipo.valueOf(o.getString("tipo")),
                monto = o.getDouble("monto"),
                categoria = o.getString("cat"),
                nota = o.optString("nota", ""),
                dia = o.getLong("dia")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun guardarMovimientos(lista: List<Movimiento>) {
        val arr = JSONArray()
        lista.forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("tipo", m.tipo.name)
                    .put("monto", m.monto)
                    .put("cat", m.categoria)
                    .put("nota", m.nota)
                    .put("dia", m.dia)
            )
        }
        prefs.edit().putString("movs", arr.toString()).apply()
    }

    fun cargarCategorias(): List<Categoria> {
        if (!prefs.contains("cats")) return categoriasIniciales()
        return try {
            val arr = JSONArray(prefs.getString("cats", "[]"))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Categoria(o.getString("nombre"), Tipo.valueOf(o.getString("tipo")))
            }
        } catch (e: Exception) {
            categoriasIniciales()
        }
    }

    fun guardarCategorias(lista: List<Categoria>) {
        val arr = JSONArray()
        lista.forEach { c ->
            arr.put(JSONObject().put("nombre", c.nombre).put("tipo", c.tipo.name))
        }
        prefs.edit().putString("cats", arr.toString()).apply()
    }

    private fun categoriasIniciales(): List<Categoria> =
        listOf("Comida", "Transporte", "Hogar", "Salud", "Ocio", "Otros")
            .map { Categoria(it, Tipo.GASTO) } +
            listOf("Sueldo", "Otros ingresos").map { Categoria(it, Tipo.INGRESO) }
}
