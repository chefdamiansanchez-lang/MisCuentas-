# Mis Cuentas
App contable Android (Kotlin + Jetpack Compose). Datos guardados en el móvil.
Subí este proyecto (o el zip) a GitHub: el workflow compila el APK y lo publica en Releases.
